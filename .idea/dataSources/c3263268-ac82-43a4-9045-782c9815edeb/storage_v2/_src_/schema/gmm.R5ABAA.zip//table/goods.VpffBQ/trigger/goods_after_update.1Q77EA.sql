create trigger goods_AFTER_UPDATE
  after UPDATE
  on goods
  for each row
  BEGIN
	if old.sold <> 1 and new.sold <> 0 then
		delete from cart as C
        where C.goodsid = old.goodsid;
	end if;		
END;

