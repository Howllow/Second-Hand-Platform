CREATE TRIGGER goods_AFTER_UPDATE
  AFTER UPDATE
  ON goods
  FOR EACH ROW
  BEGIN
	if old.sold <> 1 and new.sold <> 0 then
		delete from cart as C
        where C.goodsid = old.goodsid;
	end if;		
END;

